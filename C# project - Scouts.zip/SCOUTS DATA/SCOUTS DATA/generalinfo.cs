﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace SCOUTS_DATA
{
    public partial class generalinfo : Form
    {
        private OleDbConnection connection2 = new OleDbConnection();
 
        public generalinfo()
        {
            InitializeComponent();
            connection2.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\ALI ZAIN ALI\Documents\SCOUTSIDCARD.accdb;
Jet OLEDB:Database Password=alizainali;";
           
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void generalinfo_Load(object sender, EventArgs e)
        {

        }

        private void label_did_Click(object sender, EventArgs e)
        {

        }

        private void label_name_Click(object sender, EventArgs e)
        {

        }

        private void label_fname_Click(object sender, EventArgs e)
        {

        }

        private void label_grank_Click(object sender, EventArgs e)
        {

        }

        private void label_section_Click(object sender, EventArgs e)
        {

        }

        private void label_dob_Click(object sender, EventArgs e)
        {

        }

        private void label_cnic_Click(object sender, EventArgs e)
        {

        }

        private void label_mobile_Click(object sender, EventArgs e)
        {

        }

        private void label_phone_Click(object sender, EventArgs e)
        {

        }

        private void label_asgid_Click(object sender, EventArgs e)
        {

        }

        private void label_email_Click(object sender, EventArgs e)
        {

        }

        private void label_status_Click(object sender, EventArgs e)
        {

        }

        private void label_bgroup_Click(object sender, EventArgs e)
        {

        }

        private void label_doj_Click(object sender, EventArgs e)
        {

        }

        private void label_address_Click(object sender, EventArgs e)
        {

        }

        private void save_btn_Click(object sender, EventArgs e)
        {
            try
            {
               
                OleDbCommand command = new OleDbCommand();
                command.CommandType = System.Data.CommandType.Text;
                command.CommandText = "insert general_info (ASG-ID) values('5') ";
                command.Connection = connection2;

                connection2.Open();
                command.ExecuteNonQuery();
                MessageBox.Show("Record Saved");
                connection2.Close();   
                
            }

            catch (Exception exc)
            {
                MessageBox.Show("Error " + exc);
            }

            }
    }
}
