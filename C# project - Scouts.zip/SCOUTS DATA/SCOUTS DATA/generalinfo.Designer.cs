﻿namespace SCOUTS_DATA
{
    partial class generalinfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_asgid = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label_did = new System.Windows.Forms.Label();
            this.label_name = new System.Windows.Forms.Label();
            this.label_fname = new System.Windows.Forms.Label();
            this.label_grank = new System.Windows.Forms.Label();
            this.label_section = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label_dob = new System.Windows.Forms.Label();
            this.label_cnic = new System.Windows.Forms.Label();
            this.label_bgroup = new System.Windows.Forms.Label();
            this.label_phone = new System.Windows.Forms.Label();
            this.label_mobile = new System.Windows.Forms.Label();
            this.label_status = new System.Windows.Forms.Label();
            this.label_doj = new System.Windows.Forms.Label();
            this.label_address = new System.Windows.Forms.Label();
            this.label_email = new System.Windows.Forms.Label();
            this.asgid_txt = new System.Windows.Forms.TextBox();
            this.did_txt = new System.Windows.Forms.TextBox();
            this.fname_txt = new System.Windows.Forms.TextBox();
            this.fathername_txt = new System.Windows.Forms.TextBox();
            this.grank_txt = new System.Windows.Forms.TextBox();
            this.section_txt = new System.Windows.Forms.TextBox();
            this.dob_txt = new System.Windows.Forms.TextBox();
            this.cnic_txt = new System.Windows.Forms.TextBox();
            this.mobile_txt = new System.Windows.Forms.TextBox();
            this.phone_txt = new System.Windows.Forms.TextBox();
            this.gb_txt = new System.Windows.Forms.TextBox();
            this.doj_txt = new System.Windows.Forms.TextBox();
            this.address_txt = new System.Windows.Forms.TextBox();
            this.email_txt = new System.Windows.Forms.TextBox();
            this.status_txt = new System.Windows.Forms.TextBox();
            this.save_btn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label_asgid
            // 
            this.label_asgid.AllowDrop = true;
            this.label_asgid.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_asgid.Location = new System.Drawing.Point(18, 104);
            this.label_asgid.Name = "label_asgid";
            this.label_asgid.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label_asgid.Size = new System.Drawing.Size(139, 19);
            this.label_asgid.TabIndex = 0;
            this.label_asgid.Text = "ASG-ID";
            this.label_asgid.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.label_asgid.Click += new System.EventHandler(this.label_asgid_Click);
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.Control;
            this.textBox1.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(22, 12);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(353, 32);
            this.textBox1.TabIndex = 6;
            this.textBox1.Text = "AMYNABAD SCOUTS GROUP";
            // 
            // label_did
            // 
            this.label_did.AllowDrop = true;
            this.label_did.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_did.Location = new System.Drawing.Point(18, 136);
            this.label_did.Name = "label_did";
            this.label_did.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label_did.Size = new System.Drawing.Size(139, 19);
            this.label_did.TabIndex = 7;
            this.label_did.Text = "DISTRICT ID";
            this.label_did.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.label_did.Click += new System.EventHandler(this.label_did_Click);
            // 
            // label_name
            // 
            this.label_name.AllowDrop = true;
            this.label_name.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_name.Location = new System.Drawing.Point(18, 167);
            this.label_name.Name = "label_name";
            this.label_name.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label_name.Size = new System.Drawing.Size(139, 19);
            this.label_name.TabIndex = 8;
            this.label_name.Text = "FULL NAME";
            this.label_name.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.label_name.Click += new System.EventHandler(this.label_name_Click);
            // 
            // label_fname
            // 
            this.label_fname.AllowDrop = true;
            this.label_fname.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_fname.Location = new System.Drawing.Point(18, 198);
            this.label_fname.Name = "label_fname";
            this.label_fname.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label_fname.Size = new System.Drawing.Size(139, 19);
            this.label_fname.TabIndex = 9;
            this.label_fname.Text = "FATHER\'S NAME";
            this.label_fname.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.label_fname.Click += new System.EventHandler(this.label_fname_Click);
            // 
            // label_grank
            // 
            this.label_grank.AllowDrop = true;
            this.label_grank.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_grank.Location = new System.Drawing.Point(18, 229);
            this.label_grank.Name = "label_grank";
            this.label_grank.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label_grank.Size = new System.Drawing.Size(139, 19);
            this.label_grank.TabIndex = 10;
            this.label_grank.Text = "GROUP RANK";
            this.label_grank.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.label_grank.Click += new System.EventHandler(this.label_grank_Click);
            // 
            // label_section
            // 
            this.label_section.AllowDrop = true;
            this.label_section.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_section.Location = new System.Drawing.Point(18, 259);
            this.label_section.Name = "label_section";
            this.label_section.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label_section.Size = new System.Drawing.Size(139, 19);
            this.label_section.TabIndex = 11;
            this.label_section.Text = "SECTION";
            this.label_section.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.label_section.Click += new System.EventHandler(this.label_section_Click);
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.SystemColors.Control;
            this.textBox2.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(22, 50);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(353, 29);
            this.textBox2.TabIndex = 12;
            this.textBox2.Text = "GENERAL INFORMATION";
            // 
            // label_dob
            // 
            this.label_dob.AllowDrop = true;
            this.label_dob.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_dob.Location = new System.Drawing.Point(18, 289);
            this.label_dob.Name = "label_dob";
            this.label_dob.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label_dob.Size = new System.Drawing.Size(139, 19);
            this.label_dob.TabIndex = 13;
            this.label_dob.Text = "DATE OF BIRTH";
            this.label_dob.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.label_dob.Click += new System.EventHandler(this.label_dob_Click);
            // 
            // label_cnic
            // 
            this.label_cnic.AllowDrop = true;
            this.label_cnic.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_cnic.Location = new System.Drawing.Point(18, 318);
            this.label_cnic.Name = "label_cnic";
            this.label_cnic.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label_cnic.Size = new System.Drawing.Size(139, 19);
            this.label_cnic.TabIndex = 14;
            this.label_cnic.Text = "CNIC NUMBER";
            this.label_cnic.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.label_cnic.Click += new System.EventHandler(this.label_cnic_Click);
            // 
            // label_bgroup
            // 
            this.label_bgroup.AllowDrop = true;
            this.label_bgroup.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_bgroup.Location = new System.Drawing.Point(18, 409);
            this.label_bgroup.Name = "label_bgroup";
            this.label_bgroup.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label_bgroup.Size = new System.Drawing.Size(139, 19);
            this.label_bgroup.TabIndex = 17;
            this.label_bgroup.Text = "BLOOG GROUP";
            this.label_bgroup.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.label_bgroup.Click += new System.EventHandler(this.label_bgroup_Click);
            // 
            // label_phone
            // 
            this.label_phone.AllowDrop = true;
            this.label_phone.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_phone.Location = new System.Drawing.Point(18, 379);
            this.label_phone.Name = "label_phone";
            this.label_phone.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label_phone.Size = new System.Drawing.Size(139, 19);
            this.label_phone.TabIndex = 16;
            this.label_phone.Text = "PHONE NUMBER";
            this.label_phone.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.label_phone.Click += new System.EventHandler(this.label_phone_Click);
            // 
            // label_mobile
            // 
            this.label_mobile.AllowDrop = true;
            this.label_mobile.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_mobile.Location = new System.Drawing.Point(18, 348);
            this.label_mobile.Name = "label_mobile";
            this.label_mobile.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label_mobile.Size = new System.Drawing.Size(139, 19);
            this.label_mobile.TabIndex = 15;
            this.label_mobile.Text = "MOBILE NUMBER";
            this.label_mobile.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.label_mobile.Click += new System.EventHandler(this.label_mobile_Click);
            // 
            // label_status
            // 
            this.label_status.AllowDrop = true;
            this.label_status.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_status.Location = new System.Drawing.Point(18, 531);
            this.label_status.Name = "label_status";
            this.label_status.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label_status.Size = new System.Drawing.Size(139, 19);
            this.label_status.TabIndex = 21;
            this.label_status.Text = "STATUS";
            this.label_status.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.label_status.Click += new System.EventHandler(this.label_status_Click);
            // 
            // label_doj
            // 
            this.label_doj.AllowDrop = true;
            this.label_doj.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_doj.Location = new System.Drawing.Point(18, 500);
            this.label_doj.Name = "label_doj";
            this.label_doj.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label_doj.Size = new System.Drawing.Size(139, 19);
            this.label_doj.TabIndex = 20;
            this.label_doj.Text = "DATE OF JOINING";
            this.label_doj.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.label_doj.Click += new System.EventHandler(this.label_doj_Click);
            // 
            // label_address
            // 
            this.label_address.AllowDrop = true;
            this.label_address.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_address.Location = new System.Drawing.Point(18, 469);
            this.label_address.Name = "label_address";
            this.label_address.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label_address.Size = new System.Drawing.Size(139, 19);
            this.label_address.TabIndex = 19;
            this.label_address.Text = "ADDRESS";
            this.label_address.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.label_address.Click += new System.EventHandler(this.label_address_Click);
            // 
            // label_email
            // 
            this.label_email.AllowDrop = true;
            this.label_email.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_email.Location = new System.Drawing.Point(18, 439);
            this.label_email.Name = "label_email";
            this.label_email.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label_email.Size = new System.Drawing.Size(139, 19);
            this.label_email.TabIndex = 18;
            this.label_email.Text = "EMAIL ID";
            this.label_email.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.label_email.Click += new System.EventHandler(this.label_email_Click);
            // 
            // asgid_txt
            // 
            this.asgid_txt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.asgid_txt.Location = new System.Drawing.Point(163, 101);
            this.asgid_txt.Name = "asgid_txt";
            this.asgid_txt.Size = new System.Drawing.Size(73, 26);
            this.asgid_txt.TabIndex = 22;
            // 
            // did_txt
            // 
            this.did_txt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.did_txt.Location = new System.Drawing.Point(163, 133);
            this.did_txt.Name = "did_txt";
            this.did_txt.Size = new System.Drawing.Size(101, 26);
            this.did_txt.TabIndex = 23;
            // 
            // fname_txt
            // 
            this.fname_txt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fname_txt.Location = new System.Drawing.Point(163, 164);
            this.fname_txt.Name = "fname_txt";
            this.fname_txt.Size = new System.Drawing.Size(101, 26);
            this.fname_txt.TabIndex = 24;
            // 
            // fathername_txt
            // 
            this.fathername_txt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fathername_txt.Location = new System.Drawing.Point(163, 195);
            this.fathername_txt.Name = "fathername_txt";
            this.fathername_txt.Size = new System.Drawing.Size(101, 26);
            this.fathername_txt.TabIndex = 25;
            // 
            // grank_txt
            // 
            this.grank_txt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grank_txt.Location = new System.Drawing.Point(163, 226);
            this.grank_txt.Name = "grank_txt";
            this.grank_txt.Size = new System.Drawing.Size(101, 26);
            this.grank_txt.TabIndex = 26;
            // 
            // section_txt
            // 
            this.section_txt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.section_txt.Location = new System.Drawing.Point(163, 256);
            this.section_txt.Name = "section_txt";
            this.section_txt.Size = new System.Drawing.Size(101, 26);
            this.section_txt.TabIndex = 27;
            // 
            // dob_txt
            // 
            this.dob_txt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dob_txt.Location = new System.Drawing.Point(163, 286);
            this.dob_txt.Name = "dob_txt";
            this.dob_txt.Size = new System.Drawing.Size(101, 26);
            this.dob_txt.TabIndex = 28;
            // 
            // cnic_txt
            // 
            this.cnic_txt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cnic_txt.Location = new System.Drawing.Point(163, 315);
            this.cnic_txt.Name = "cnic_txt";
            this.cnic_txt.Size = new System.Drawing.Size(101, 26);
            this.cnic_txt.TabIndex = 29;
            // 
            // mobile_txt
            // 
            this.mobile_txt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mobile_txt.Location = new System.Drawing.Point(163, 345);
            this.mobile_txt.Name = "mobile_txt";
            this.mobile_txt.Size = new System.Drawing.Size(101, 26);
            this.mobile_txt.TabIndex = 30;
            // 
            // phone_txt
            // 
            this.phone_txt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.phone_txt.Location = new System.Drawing.Point(163, 375);
            this.phone_txt.Name = "phone_txt";
            this.phone_txt.Size = new System.Drawing.Size(101, 26);
            this.phone_txt.TabIndex = 31;
            // 
            // gb_txt
            // 
            this.gb_txt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_txt.Location = new System.Drawing.Point(163, 406);
            this.gb_txt.Name = "gb_txt";
            this.gb_txt.Size = new System.Drawing.Size(101, 26);
            this.gb_txt.TabIndex = 32;
            // 
            // doj_txt
            // 
            this.doj_txt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.doj_txt.Location = new System.Drawing.Point(163, 497);
            this.doj_txt.Name = "doj_txt";
            this.doj_txt.Size = new System.Drawing.Size(101, 26);
            this.doj_txt.TabIndex = 33;
            // 
            // address_txt
            // 
            this.address_txt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.address_txt.Location = new System.Drawing.Point(163, 466);
            this.address_txt.Name = "address_txt";
            this.address_txt.Size = new System.Drawing.Size(101, 26);
            this.address_txt.TabIndex = 34;
            // 
            // email_txt
            // 
            this.email_txt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.email_txt.Location = new System.Drawing.Point(163, 436);
            this.email_txt.Name = "email_txt";
            this.email_txt.Size = new System.Drawing.Size(101, 26);
            this.email_txt.TabIndex = 35;
            // 
            // status_txt
            // 
            this.status_txt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.status_txt.Location = new System.Drawing.Point(163, 528);
            this.status_txt.Name = "status_txt";
            this.status_txt.Size = new System.Drawing.Size(101, 26);
            this.status_txt.TabIndex = 36;
            // 
            // save_btn
            // 
            this.save_btn.Location = new System.Drawing.Point(53, 573);
            this.save_btn.Name = "save_btn";
            this.save_btn.Size = new System.Drawing.Size(75, 23);
            this.save_btn.TabIndex = 37;
            this.save_btn.Text = "SAVE RECORD";
            this.save_btn.UseVisualStyleBackColor = true;
            this.save_btn.Click += new System.EventHandler(this.save_btn_Click);
            // 
            // generalinfo
            // 
            this.AllowDrop = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(373, 605);
            this.Controls.Add(this.save_btn);
            this.Controls.Add(this.status_txt);
            this.Controls.Add(this.email_txt);
            this.Controls.Add(this.address_txt);
            this.Controls.Add(this.doj_txt);
            this.Controls.Add(this.gb_txt);
            this.Controls.Add(this.phone_txt);
            this.Controls.Add(this.mobile_txt);
            this.Controls.Add(this.cnic_txt);
            this.Controls.Add(this.dob_txt);
            this.Controls.Add(this.section_txt);
            this.Controls.Add(this.grank_txt);
            this.Controls.Add(this.fathername_txt);
            this.Controls.Add(this.fname_txt);
            this.Controls.Add(this.did_txt);
            this.Controls.Add(this.asgid_txt);
            this.Controls.Add(this.label_status);
            this.Controls.Add(this.label_doj);
            this.Controls.Add(this.label_address);
            this.Controls.Add(this.label_email);
            this.Controls.Add(this.label_bgroup);
            this.Controls.Add(this.label_phone);
            this.Controls.Add(this.label_mobile);
            this.Controls.Add(this.label_cnic);
            this.Controls.Add(this.label_dob);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label_section);
            this.Controls.Add(this.label_grank);
            this.Controls.Add(this.label_fname);
            this.Controls.Add(this.label_name);
            this.Controls.Add(this.label_did);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label_asgid);
            this.Name = "generalinfo";
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Text = "generalinfo";
            this.Load += new System.EventHandler(this.generalinfo_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_asgid;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label_did;
        private System.Windows.Forms.Label label_name;
        private System.Windows.Forms.Label label_fname;
        private System.Windows.Forms.Label label_grank;
        private System.Windows.Forms.Label label_section;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label_dob;
        private System.Windows.Forms.Label label_cnic;
        private System.Windows.Forms.Label label_bgroup;
        private System.Windows.Forms.Label label_phone;
        private System.Windows.Forms.Label label_mobile;
        private System.Windows.Forms.Label label_status;
        private System.Windows.Forms.Label label_doj;
        private System.Windows.Forms.Label label_address;
        private System.Windows.Forms.Label label_email;
        private System.Windows.Forms.TextBox asgid_txt;
        private System.Windows.Forms.TextBox did_txt;
        private System.Windows.Forms.TextBox fname_txt;
        private System.Windows.Forms.TextBox fathername_txt;
        private System.Windows.Forms.TextBox grank_txt;
        private System.Windows.Forms.TextBox section_txt;
        private System.Windows.Forms.TextBox dob_txt;
        private System.Windows.Forms.TextBox cnic_txt;
        private System.Windows.Forms.TextBox mobile_txt;
        private System.Windows.Forms.TextBox phone_txt;
        private System.Windows.Forms.TextBox gb_txt;
        private System.Windows.Forms.TextBox doj_txt;
        private System.Windows.Forms.TextBox address_txt;
        private System.Windows.Forms.TextBox email_txt;
        private System.Windows.Forms.TextBox status_txt;
        private System.Windows.Forms.Button save_btn;
    }
}