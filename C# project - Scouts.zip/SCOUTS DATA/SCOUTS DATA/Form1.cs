﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace SCOUTS_DATA
{
    public partial class Form1 : Form
    {
        private OleDbConnection connection = new OleDbConnection();
        public Form1()
        {
            InitializeComponent();
            connection.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\ALI ZAIN ALI\Documents\SCOUTSIDCARD.accdb;
Jet OLEDB:Database Password=alizainali;";
        }

        private void btn_Login_Click(object sender, EventArgs e)
        {
            connection.Open();
            OleDbCommand command = new OleDbCommand();
            command.Connection = connection;
            command.CommandText = "select * from login where USERNAME = '" + txt_Username.Text + "' and PASSWORD = '" + txt_Password.Text + "'";
            OleDbDataReader reader = command.ExecuteReader();
            int count = 0;
            while (reader.Read())
            {
                count++;
            }
            if (count == 1)
            {
                //MessageBox.Show("LOGIN SUCCESSFUL");
                connection.Close();
                connection.Dispose();
                this.Hide();
                main f2 = new main();
                f2.ShowDialog();
            }
            else if (count > 1)
            {
                MessageBox.Show("DUPLICATE USERNAME AND PASSWORD");
                txt_Username.Text = String.Empty;
                txt_Password.Text = String.Empty;
            }
            else
            {
                MessageBox.Show("INCORRECT USERNAME OR PASSWORD");
                txt_Username.Text = String.Empty;
                txt_Password.Text = String.Empty;

            }


            connection.Close();
        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {
           
        }

        private void txt_Username_KeyDown(object sender, KeyEventArgs e)
        {
            if 
                (e.KeyCode == Keys.Enter)
            {
                btn_Login_Click(this, new EventArgs());
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
