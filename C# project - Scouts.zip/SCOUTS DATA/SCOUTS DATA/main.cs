﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;


namespace SCOUTS_DATA
{
    public partial class main : Form
    {
        public OleDbConnection connection = new OleDbConnection();
        public main()
        {
            InitializeComponent();
            connection.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\ALI ZAIN ALI\Documents\SCOUTSIDCARD.accdb;
Jet OLEDB:Database Password=alizainali;";
            connection.Open();  //connection not closed yet!
        }

        private void button1_Click(object sender, EventArgs e)
        {
           // connection.Open();
            OleDbCommand command = new OleDbCommand();
            //connection.Close();
            connection.Dispose();
            generalinfo f4 = new generalinfo();
            f4.ShowDialog();
            connection.Close();

        }

        private void btn_AssignRights_Click(object sender, EventArgs e)
        {
            
           // connection.Open();
            OleDbCommand command = new OleDbCommand();
           // connection.Close();
            connection.Dispose();
            assignrights f3 = new assignrights();
            f3.ShowDialog();


        }

        private void main_Load(object sender, EventArgs e)
        {

        }
    }
}
